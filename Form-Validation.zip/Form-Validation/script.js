jQuery(document).ready(function($) {
    $(".submit").on("click", function(e) {
        e.preventDefault();

        let status = true; 
        var firstname = $("#first-name").val();
        var lastname = $("#last-name").val();
        var dob = $("#dob").val();
        var phonenumber = $("#phone-no").val();
        var email = $("#email").val();
        var address = $("#address").val();
        var password = $("#password").val();
        var confirmPassword = $("#confirm-password").val();

        $(".error-message").html("");

        if (firstname.length > 8) {
            $("#first-name").siblings(".error-message").html("<p>First name must be within 8 characters</p>");
            status = false;
        }

        if (status && lastname.length > 8) {
            $("#last-name").siblings(".error-message").html("<p>Last name must be within 8 characters</p>");
            status = false;
        }

        if (status && phonenumber.length > 15) {
            $("#phone-no").siblings(".error-message").html("<p>Phone number must be within 15 characters</p>");
            status = false;
        }

        if (status && address.length > 25) {
            $("#address").siblings(".error-message").html("<p>Address must be within 25 characters</p>");
            status = false;
        }

        if (status && password !== confirmPassword) {
            $("#confirm-password").siblings(".error-message").html("<p>Passwords do not match</p>");
            status = false;
        }

        if (status) {
            $(".registration_form").submit();
        }
    });
});
